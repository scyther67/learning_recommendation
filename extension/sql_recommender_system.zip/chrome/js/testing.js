chrome.runtime.sendMessage({
    onTesting: true
});